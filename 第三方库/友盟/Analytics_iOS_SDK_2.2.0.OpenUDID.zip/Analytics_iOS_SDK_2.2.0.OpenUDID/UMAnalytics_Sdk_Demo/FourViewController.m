/*
     File: FourViewController.m 
 Abstract: The view controller for page four. 
  Version: 1.0 
  
 Disclaimer: IMPORTANT:  This Apple software is supplied to you by Apple 
 Inc. ("Apple") in consideration of your agreement to the following 
 terms, and your use, installation, modification or redistribution of 
 this Apple software constitutes acceptance of these terms.  If you do 
 not agree with these terms, please do not use, install, modify or 
 redistribute this Apple software. 
  
 In consideration of your agreement to abide by the following terms, and 
 subject to these terms, Apple grants you a personal, non-exclusive 
 license, under Apple's copyrights in this original Apple software (the 
 "Apple Software"), to use, reproduce, modify and redistribute the Apple 
 Software, with or without modifications, in source and/or binary forms; 
 provided that if you redistribute the Apple Software in its entirety and 
 without modifications, you must retain this notice and the following 
 text and disclaimers in all such redistributions of the Apple Software. 
 Neither the name, trademarks, service marks or logos of Apple Inc. may 
 be used to endorse or promote products derived from the Apple Software 
 without specific prior written permission from Apple.  Except as 
 expressly stated in this notice, no other rights or licenses, express or 
 implied, are granted by Apple herein, including but not limited to any 
 patent rights that may be infringed by your derivative works or by other 
 works in which the Apple Software may be incorporated. 
  
 The Apple Software is provided by Apple on an "AS IS" basis.  APPLE 
 MAKES NO WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION 
 THE IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS 
 FOR A PARTICULAR PURPOSE, REGARDING THE APPLE SOFTWARE OR ITS USE AND 
 OPERATION ALONE OR IN COMBINATION WITH YOUR PRODUCTS. 
  
 IN NO EVENT SHALL APPLE BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL 
 OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 INTERRUPTION) ARISING IN ANY WAY OUT OF THE USE, REPRODUCTION, 
 MODIFICATION AND/OR DISTRIBUTION OF THE APPLE SOFTWARE, HOWEVER CAUSED 
 AND WHETHER UNDER THEORY OF CONTRACT, TORT (INCLUDING NEGLIGENCE), 
 STRICT LIABILITY OR OTHERWISE, EVEN IF APPLE HAS BEEN ADVISED OF THE 
 POSSIBILITY OF SUCH DAMAGE. 
  
 Copyright (C) 2011 Apple Inc. All Rights Reserved. 
  
 */

#import "FourViewController.h"
#import "MobClick.h"

@implementation FourViewController

@synthesize titleLabel;

// The designated initializer.
// Override to perform setup that is required before the view property is loaded.
//
// note:
// This won't be called in this case because this view controller is loaded directly from the nib.
// If you allocate FourViewController from code, this will be called.
//
//- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
//

// this is called when the UITabBarController loads it's views at launch time
- (void)awakeFromNib
{
	// make our tabbar icon a custom one;
	// we could do it in Interface Builder, but this is just to illustrate a point about
	// using awakeFromNib vs. viewDidLoad.
	//
	UITabBarItem *customTab = [[UITabBarItem alloc] initWithTitle:@"Four"
															image:[UIImage imageNamed:@"tab4.png"]
															  tag:0];
	self.tabBarItem = customTab;
	[customTab release];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [MobClick endLogPageView:@"FourPage"];
}

- (void)viewWillAppear:(BOOL)animated
{
	[super viewWillAppear:animated];
	
	// if we were navigated to through the More screen table, then we have a navigation bar which
	// also means we have a title.  So hide the title label in this case, otherwise, we need it
	//
	if ([self.parentViewController isKindOfClass:[UINavigationController class]])
		self.titleLabel.hidden = YES;
	else
		self.titleLabel.hidden = NO;

    [MobClick beginLogPageView:@"FourPage"];
}

- (void)viewDidUnload
{
	self.titleLabel = nil;
	
	[super viewDidUnload];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
	return YES; // support all orientations
}


- (IBAction)checkUpdateButtonClick:(id)sender {
    [MobClick checkUpdate:@"New version" cancelButtonTitle:@"Skip" otherButtonTitles:@"Goto Store"];
}

- (IBAction)checkOnlineConfigButtonClick:(id)sender {
    
    NSString * switcher= [MobClick getConfigParams:@"ad_switchers"];
    if ([switcher isEqualToString:@"on"]) {
        NSLog(@"showAds");
    } else{
        NSLog(@"hideAds");
    }    
}



- (IBAction)exception {
	NSArray *array = [NSArray array];
    [array objectAtIndex:NSUIntegerMax];
}

//分析SDK里的单向反馈下个版本将被移除
- (IBAction)showFeedback:(id)sender {
//    [MobClick showFeedback:self];
    NSLog(@"统计SDK自带的单向反馈已经去除，请使用独立的双向用户反馈SDK");
    NSLog(@"http://dev.umeng.com/doc/document_fb_ios.html");
}


@end
