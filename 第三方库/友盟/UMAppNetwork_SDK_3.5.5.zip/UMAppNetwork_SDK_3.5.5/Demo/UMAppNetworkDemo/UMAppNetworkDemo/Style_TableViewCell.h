//
//  Style_TableViewCell.h
//  UFP
//
//  Created by liuyu on 10/11/12.
//  Copyright (c) 2012 Realcent. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Style_TableViewCell : UITableViewCell {
    
    UIImageView *rightArrow;
}

@end
