//
//  UMBannerViewController.h
//  UFP
//
//  Created by liu yu on 5/14/12.
//  Copyright (c) 2012 Realcent. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UMUFPBannerView.h"

@interface UMBannerViewController : UIViewController {
    
    UMUFPBannerView *banner;
}

@end
