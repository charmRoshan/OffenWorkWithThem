//
//  UMHandleViewController.h
//  UFP
//
//  Created by liu yu on 8/1/12.
//  Copyright (c) 2012 Realcent. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UMUFPHandleView.h"

@interface UMHandleViewController : UIViewController {
    
    UMUFPHandleView *_mHandleView;
}

@end
