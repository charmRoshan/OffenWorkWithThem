//
//  AppDelegate.h
//  UMUFPDemo
//
//  Created by liu yu on 2/28/12.
//  Copyright (c) 2012 Realcent. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (retain, nonatomic) UIWindow *window;

@property (retain, nonatomic) UINavigationController *viewController;

@end
