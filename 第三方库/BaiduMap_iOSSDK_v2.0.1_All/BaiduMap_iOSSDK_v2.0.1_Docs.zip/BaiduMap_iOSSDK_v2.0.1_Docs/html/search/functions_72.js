var searchData=
[
  ['rectformaprect_3a',['rectForMapRect:',['../interface_b_m_k_overlay_view.html#a4eb52fd9951bcfc898e9a026ee40e99e',1,'BMKOverlayView']]],
  ['regionthatfits_3a',['regionThatFits:',['../interface_b_m_k_map_view.html#a5a1387f64868bf341cbf743063a91d28',1,'BMKMapView']]],
  ['remove_3a',['remove:',['../interface_b_m_k_offline_map.html#ac834ae7e577d2fa4dc864232b30f02df',1,'BMKOfflineMap']]],
  ['removeannotation_3a',['removeAnnotation:',['../interface_b_m_k_map_view.html#a5a6efcf38e824c225c8dc3132edb4c02',1,'BMKMapView']]],
  ['removeannotations_3a',['removeAnnotations:',['../interface_b_m_k_map_view.html#aa3cccccb36e36704debcdeb0093559f2',1,'BMKMapView']]],
  ['removeoverlay_3a',['removeOverlay:',['../category_b_m_k_map_view_07_overlays_a_p_i_08.html#a3be1f2a019df3ff971f6a36f142e55be',1,'BMKMapView(OverlaysAPI)::removeOverlay:()'],['../interface_b_m_k_map_view.html#a3be1f2a019df3ff971f6a36f142e55be',1,'BMKMapView::removeOverlay:()']]],
  ['removeoverlays_3a',['removeOverlays:',['../category_b_m_k_map_view_07_overlays_a_p_i_08.html#a3eb7909fb1adce117c1de432fd5d816a',1,'BMKMapView(OverlaysAPI)::removeOverlays:()'],['../interface_b_m_k_map_view.html#a3eb7909fb1adce117c1de432fd5d816a',1,'BMKMapView::removeOverlays:()']]],
  ['renderlineswithpoints_3apointcount_3astrokecolor_3alinewidth_3alooped_3a',['renderLinesWithPoints:pointCount:strokeColor:lineWidth:looped:',['../interface_b_m_k_overlay_view.html#a67fcc048446dfa1725aa4a86b241b282',1,'BMKOverlayView']]],
  ['renderregionwithpoints_3apointcount_3afillcolor_3ausingtrianglefan_3a',['renderRegionWithPoints:pointCount:fillColor:usingTriangleFan:',['../interface_b_m_k_overlay_view.html#a85a054df49b09373b036e22771138ba2',1,'BMKOverlayView']]],
  ['reversegeocode_3a',['reverseGeocode:',['../interface_b_m_k_search.html#ae5169b6362dda612ffd1f1b5f9df6137',1,'BMKSearch']]]
];
