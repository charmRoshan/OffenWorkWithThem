var searchData=
[
  ['boundingmaprect',['boundingMapRect',['../interface_b_m_k_circle.html#a462a1696e47b1523dd481b22d43bcf46',1,'BMKCircle::boundingMapRect()'],['../protocol_b_m_k_overlay-p.html#a77465daa9e52be51cc5aa15591ab74f0',1,'BMKOverlay-p::boundingMapRect()']]]
];
