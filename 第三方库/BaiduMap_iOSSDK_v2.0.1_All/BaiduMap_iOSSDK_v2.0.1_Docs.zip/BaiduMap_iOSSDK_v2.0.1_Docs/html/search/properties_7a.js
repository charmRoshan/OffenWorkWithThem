var searchData=
[
  ['zoomenabled',['zoomEnabled',['../interface_b_m_k_map_view.html#acf8472da994b76cef21a40673a41f774',1,'BMKMapView']]],
  ['zoomlevel',['zoomLevel',['../interface_b_m_k_map_view.html#a5e6c1e21fddd4d6a24194be53f14c27e',1,'BMKMapView']]]
];
