var searchData=
[
  ['_5f_5fosx_5favailable_5fstarting',['__OSX_AVAILABLE_STARTING',['../interface_b_m_k_annotation_view.html#a54d15e7cc4e89d89d2233ec7fc408ad9',1,'BMKAnnotationView::__OSX_AVAILABLE_STARTING(__MAC_NA, __IPHONE_3_2)'],['../interface_b_m_k_annotation_view.html#a623e818d48c983176a6553104b21a34c',1,'BMKAnnotationView::__OSX_AVAILABLE_STARTING(__MAC_NA, __IPHONE_3_2)']]]
];
