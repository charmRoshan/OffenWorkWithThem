var searchData=
[
  ['zoomin',['zoomIn',['../interface_b_m_k_map_view.html#a349f7c74871a389d73955edd7bcd9fdf',1,'BMKMapView']]],
  ['zoomout',['zoomOut',['../interface_b_m_k_map_view.html#a1806c818757917ef674ebe5ba24fe5a2',1,'BMKMapView']]]
];
