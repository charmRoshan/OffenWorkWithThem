var searchData=
[
  ['walkingsearch_3astartnode_3aendcity_3aendnode_3a',['walkingSearch:startNode:endCity:endNode:',['../interface_b_m_k_search.html#aa2a9b0f69520e4e17ff9504d10e77f57',1,'BMKSearch']]]
];
