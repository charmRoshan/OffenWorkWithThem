var searchData=
[
  ['viastopsnum',['viaStopsNum',['../interface_b_m_k_line.html#a0790fa0eb9e8f2d9db0d23e71a0af5d5',1,'BMKLine']]],
  ['visiblemaprect',['visibleMapRect',['../interface_b_m_k_map_view.html#a35576ab39592ef50d1190c2b672c0923',1,'BMKMapView']]]
];
