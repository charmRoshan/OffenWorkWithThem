var searchData=
[
  ['size',['size',['../struct_b_m_k_map_rect.html#ab83b0fb9e6e63b6ab24bdce9ced1e92e',1,'BMKMapRect']]],
  ['span',['span',['../struct_b_m_k_coordinate_region.html#a75e65758cbbf7cb3ed6007d4ce301292',1,'BMKCoordinateRegion']]]
];
