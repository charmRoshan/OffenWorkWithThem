var searchData=
[
  ['addannotation_3a',['addAnnotation:',['../interface_b_m_k_map_view.html#a1bf0349f0eb4580ca23eac1032345925',1,'BMKMapView']]],
  ['addannotations_3a',['addAnnotations:',['../interface_b_m_k_map_view.html#ad863c0ccb09937907188a408103f8234',1,'BMKMapView']]],
  ['addoverlay_3a',['addOverlay:',['../category_b_m_k_map_view_07_overlays_a_p_i_08.html#af85ad6091568df29d9e7c3dea82a1a2b',1,'BMKMapView(OverlaysAPI)::addOverlay:()'],['../interface_b_m_k_map_view.html#af85ad6091568df29d9e7c3dea82a1a2b',1,'BMKMapView::addOverlay:()']]],
  ['addoverlays_3a',['addOverlays:',['../category_b_m_k_map_view_07_overlays_a_p_i_08.html#ab7d29d948515cc6d947d6aa63f904168',1,'BMKMapView(OverlaysAPI)::addOverlays:()'],['../interface_b_m_k_map_view.html#ab7d29d948515cc6d947d6aa63f904168',1,'BMKMapView::addOverlays:()']]],
  ['applyfillpropertiestocontext_3aatzoomscale_3a',['applyFillPropertiesToContext:atZoomScale:',['../interface_b_m_k_overlay_path_view.html#af549bea37a94164a088826f9a962e08c',1,'BMKOverlayPathView']]],
  ['applystrokepropertiestocontext_3aatzoomscale_3a',['applyStrokePropertiesToContext:atZoomScale:',['../interface_b_m_k_overlay_path_view.html#a2acbf6bd9401c2904148b7b6cf85c6e9',1,'BMKOverlayPathView']]]
];
