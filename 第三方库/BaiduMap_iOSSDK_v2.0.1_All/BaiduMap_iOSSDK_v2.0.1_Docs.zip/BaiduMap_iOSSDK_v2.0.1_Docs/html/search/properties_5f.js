var searchData=
[
  ['_5fname',['_name',['../interface_b_m_k_poi_info.html#ab34c02df04b959fa0d2cfa141cd50c1e',1,'BMKPoiInfo']]],
  ['_5ftotalpoinum',['_totalPoiNum',['../interface_b_m_k_poi_result.html#a4a48255798b55903c7ffc1f4a5fd20aa',1,'BMKPoiResult']]]
];
